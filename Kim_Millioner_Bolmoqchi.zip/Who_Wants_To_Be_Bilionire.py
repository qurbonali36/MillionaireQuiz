import json
import random



def load_json(file_name, default_value):
    try:
        with open(file_name, "r") as file:
            return json.load(file)
    except FileNotFoundError:
        return default_value


savol_javoblar = load_json("tests.json", [])


def test_working():
    help_count = 1
    ball = 0
    shuffled_questions = random.sample(savol_javoblar, len(savol_javoblar))

    for savol_obj in shuffled_questions:
        print("\n" + "=" * 30)
        print(f"SAVOL: {savol_obj['question']}")
        variantlar = ["A)", "B)", "C)", "D)"]

        for i, javob in enumerate(savol_obj["answers"]):
            print(f"{variantlar[i]} {javob['key']}")

        if help_count > 0:
            print("Y) Yordam (50/50)")

        while True:
            answer = input("\nJavobingizni kiriting: ").lower().strip()

            if answer == 'y' and help_count > 0:
                answers = savol_obj["answers"]
                togri = next(j for j in answers if j["isTrue"])
                notogri_variantlar = [j for j in answers if not j["isTrue"]]
                tasodifiy_notogri = random.choice(notogri_variantlar)

                print(f"\nYORDAM: Ikkita variant qoldi:")
                print(f"--- {togri['key']}")
                print(f"--- {tasodifiy_notogri['key']}")
                help_count = 0
                continue

            if answer in ['a', 'b', 'c', 'd']:
                harflar_map = {"a": 0, "b": 1, "c": 2, "d": 3}
                tanlangan_javob = savol_obj["answers"][harflar_map[answer]]

                if tanlangan_javob["isTrue"]:
                    print("To'g'ri javob!")
                    ball += 1
                    break
                else:
                    print(f"Noto'g'ri! To'g'ri javob: {next(j['key'] for j in savol_obj['answers'] if j['isTrue'])}")
                    print(f"Sizning natijangiz: {ball} ball.")
                    return ball
            else:
                print("Iltimos, faqat A, B, C, D yoki Y harflarini kiriting!")

    print(f"\nTABRIKLAYMIZ! Siz barcha savollarga javob berdingiz. Ball: {ball}")
    return ball


def save_result(name, score):
    users_name = load_json("Users_Name.json", [])

    topildi = False
    for info in users_name:
        if info["name"].lower() == name.lower():
            info["total_games"] += 1
            if score > info["score"]:
                info["score"] = score
            topildi = True
            break

    if not topildi:
        users_name.append({
            "name": name,
            "score": score,
            "total_games": 1
        })


    with open("Users_Name.json", "w") as fayl:
        json.dump(users_name, fayl, indent=4)


def see_result():
    users = load_json("Users_Name.json", [])
    if not users:
        print("\nHali hech qanday natija yo'q.")
        return


    users.sort(key=lambda x: x['score'], reverse=True)

    print("\n" + "ID".ljust(4) + "ISM".ljust(15) + "BALL".ljust(8) + "O'YINLAR")
    print("-" * 40)
    for i, user in enumerate(users, 1):
        print(f"{str(i).ljust(4)}{user['name'].ljust(15)}{str(user['score']).ljust(8)}{user['total_games']}")



print("=== KIM MILLIONER BO'LMOQCHI? ===")
user_name = input("Ismingizni kiriting: ")

while True:
    menyu = input("""
    Menyuni tanlang:
    1. Test ishlash
    2. Statistika
    0. Chiqish
    >>> """)

    if menyu == "0":
        print("O'yin to'xtatildi!")
        break
    elif menyu == "1":
        ball = test_working()
        save_result(user_name, ball)
    elif menyu == "2":
        see_result()
    else:
        print("Xato tanlov!")